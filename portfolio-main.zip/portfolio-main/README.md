<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

<h1>Portfolio in Laravel and MySQL</h1>
I used laravel eloquent model to create relationships between the user(Me) and my projects (one-many) which made fetching specific or all projects easier in the controllers

## Modern UI (Responsive) -- I spent a good amount of figuring out the design of the website (Looks best on desktop PC)
It designed and coded in such a way that its easy responsive across all devices

### I hosted it using a free account on heroku and a free remote MySQL account - (Some users might face some latency issues -- due to my free plan for MySQL -- sorry for that, still a college student)
